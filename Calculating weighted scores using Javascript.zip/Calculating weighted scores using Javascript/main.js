document.getElementById('calculate-button').addEventListener('click', function() {
    //Variables
    const weights = [];
    const users = ['user1', 'user2', 'user3'];
    const traits = ['confident', 'caring', 'smart', 'strong', 'humorous'];
    const characters = ['dean', 'sam', 'john', 'castiel', 'crowley'];

    // Calculate weights for each user
    users.forEach(function(user, userIndex) {
        let userWeights = [];
        let weightTotal = 0;
        traits.forEach(function(trait) {
            let weight = parseFloat(document.getElementById('weight-' + user + '-' + trait).value);
            userWeights.push(weight);
            weightTotal = weightTotal + weight; 
        });

        // Check if weights total to 100 and if they don't it will throw an error message
        if (weightTotal !== 100) {
            alert('User ' + (userIndex + 1) + ' weights are not equal to 100!');
            return;
        }

        weights.push(userWeights);
    });

    // Calculates scores and shows the scores in the results table
    users.forEach(function(user, userIndex) {
        let scores = [];
        characters.forEach(function(character, characterIndex) {
            let score = 0;
            traits.forEach(function(trait, traitIndex) {
                let selectElement = document.querySelector('#characters-table .' + trait + ' select');
                let value = parseFloat(selectElement.value);
                score += value * weights[userIndex][traitIndex] / 100 
            });
            scores.push(parseFloat(score.toFixed(2)));
        });

        // Determines highest and lowest scores
        let highestScoreIndex = scores.indexOf(Math.max(...scores));
        let lowestScoreIndex = scores.indexOf(Math.min(...scores));

        // Populates the results table and changes the color of the cells based on highest and lowest scores
        characters.forEach(function(character, characterIndex) {
            let cell = document.getElementById('score-' + user + '-' + character);
            cell.innerText = scores[characterIndex];

            // Reset previous styles
            //cell.style.backgroundColor = '';

            // Highlights the highest score in green
            if (characterIndex === highestScoreIndex) {
                cell.style.backgroundColor = 'green';
            }

            // Highlights the lowest score in red
            if (characterIndex === lowestScoreIndex) {
                cell.style.backgroundColor = 'red';
            }
        });
    });
});