# Goal

Creating a python program that converts a string of 
text to a salted hash (using multiple hashing algorithms).

# Python Version

The Python version last tested against is 3.12.1.

# Libraries Used

The libraries that I used for this project are Tkinter, HashLib,
and OS. These libraries normally come built into 
Python, so you shouldn't have to install any external
libraries.

# Additional Considerations

No additional considerations are needed for this program
to run.