# Name: Frazia Kipimo
# Project: Hashing Algorithms

#Libraries
import hashlib
import os
import tkinter as tk
from tkinter import *
from tkinter import messagebox

# Creating a window and naming it
window = Tk()
window.title("Hashing Algorithms")
window.geometry("900x540")

#Method that when called, shows the password entered, and takes the password entered and converts it to a SHA-256 Hash and an MD5 Hash.
def submit_data():
    # Creates a label for and displays "Password entered: " followed by the password the user entered
    label_widget2 = Label(window, text="Password entered: " + entry_widget1.get(), bg="cyan2")
    canvas_widget.create_window(88, 60, window=label_widget2)

    # Converts the password to a salted SHA-256 Hash
    string1 = entry_widget1.get()
    salt = os.urandom(32)
    hash_data = hashlib.sha256(string1.encode() + salt)
    hashed = hash_data.hexdigest()
    # Created a label for and displays "SHA-256 Hash: " followed by the salted hashed value
    label_widget3 = Label(window, text="SHA-256 Hash: " + hashed, bg="cyan2")
    canvas_widget.create_window(238, 100, window=label_widget3)

    # Converts the password to a salted MD5 Hash
    md5_data = hashlib.md5(string1.encode() + salt)
    md5_hashed = md5_data.hexdigest()
    # Created a label for and displays "MD5 Hash: " followed by the salted hashed value
    label_widget4 = Label(window, text="MD5 Hash: " + md5_hashed, bg="cyan2")
    canvas_widget.create_window(130, 140, window=label_widget4)

    # Converts the password to a salted SHA-1 Hash
    sha1_data = hashlib.sha1(string1.encode() + salt)
    sha1_hashed = sha1_data.hexdigest()
    # Created a label for and displays "SHA-1 Hash: " followed by the salted hashed value
    label_widget5 = Label(window, text="SHA-1 Hash: " + sha1_hashed, bg="cyan2")
    canvas_widget.create_window(156, 180, window=label_widget5)

    # Converts the password to a salted SHA-2_512 Hash
    sha512_data = hashlib.sha512(string1.encode() + salt)
    sha512_hashed = sha512_data.hexdigest()
    # Created a label for and displays "SHA-2_512 Hash: " followed by the salted hashed value
    label_widget6 = Label(window, text="SHA-2_512 Hash: " + sha512_hashed, bg="cyan2")
    canvas_widget.create_window(430, 220, window=label_widget6)

    # Converts the password to a salted SHA-3 256 Hash
    sha3_data = hashlib.sha3_256(string1.encode() + salt)
    sha3_hashed = sha3_data.hexdigest()
    # Created a label for and displays "SHA-3_256 Hash: " followed by the salted hashed value
    label_widget7 = Label(window, text="SHA-3_256 Hash: " + sha3_hashed, bg="cyan2")
    canvas_widget.create_window(234, 260, window=label_widget7)

    # Converts the password to a salted Blake2b Hash
    blake2b_data = hashlib.blake2b(string1.encode() + salt)
    blake2b_hashed = blake2b_data.hexdigest()
    # Created a label for and displays "Blake2b Hash: " followed by the salted hashed value
    label_widget8 = Label(window, text="Blake2b Hash: " + blake2b_hashed, bg="cyan2")
    canvas_widget.create_window(428, 300, window=label_widget8)

    # Converts the password to a salted Blake2s Hash
    blake2s_data = hashlib.blake2s(string1.encode() + salt)
    blake2s_hashed = blake2s_data.hexdigest()
    # Created a label for and displays "Blake2s Hash: " followed by the salted hashed value
    label_widget9 = Label(window, text="Blake2s Hash: " + blake2s_hashed, bg="cyan2")
    canvas_widget.create_window(234, 340, window=label_widget9)

    # Converts the password to a salted SHA-3 512 Hash
    sha3_512_data = hashlib.sha3_512(string1.encode() + salt)
    sha3_512_hashed = sha3_512_data.hexdigest()
    # Created a label for and displays "SHA-3_512 Hash: " followed by the salted hashed value
    label_widget11 = Label(window, text="SHA-3_512 Hash: " + sha3_512_hashed, bg="cyan2")
    canvas_widget.create_window(430, 380, window=label_widget11)

    # Converts the password to a salted Shake_128 Hash
    shake_128_data = hashlib.shake_128(string1.encode() + salt)
    shake_128_hashed = shake_128_data.hexdigest(32)
    # Created a label for and displays "Shake_128 Hash: " followed by the salted hashed value
    label_widget11 = Label(window, text="Shake_128 Hash: " + shake_128_hashed, bg="cyan2")
    canvas_widget.create_window(244, 420, window=label_widget11)

    # Converts the password to a salted Shake_256 Hash
    shake_256_data = hashlib.shake_256(string1.encode() + salt)
    shake_256_hashed = shake_256_data.hexdigest(32)
    # Created a label for and displays "Shake_256 Hash: " followed by the salted hashed value
    label_widget12 = Label(window, text="Shake_256 Hash: " + shake_256_hashed, bg="cyan2")
    canvas_widget.create_window(244, 460, window=label_widget12)

    # Converts the password to a salted SHA-3_384 Hash
    sha3_384_data = hashlib.sha3_384(string1.encode() + salt)
    sha3_384_hashed = sha3_384_data.hexdigest()
    # Created a label for and displays "SHA-3_384 Hash: " followed by the salted hashed value
    label_widget13 = Label(window, text="SHA-3_384 Hash: " + sha3_384_hashed, bg="cyan2")
    canvas_widget.create_window(336, 500, window=label_widget13)

# Creates a canvas window, sizes it, and changes the background color
canvas_widget = Canvas(window, width=1600, height=750, background="cyan2")
canvas_widget.pack()

# Prompts the user to enter a password
entry_widget1 = Entry(window, show="*")
label_widget1 = Label(window, text="Enter a password: " + entry_widget1.get(), bg="cyan2")


canvas_widget.create_window(54, 20, window=label_widget1)
canvas_widget.create_window(170, 20, window=entry_widget1)

# When the submit button is clicked, it tells my program to run the submit_data method to convert the password to hashes.
button_widget = Button(window, text='Submit', command=submit_data)
canvas_widget.create_window(260, 20, window=button_widget)

# Methods

# Method for exiting the program
def exit_app():
    if messagebox.askyesno("Menu", "Do you want to exit?"):
        window.destroy()
# Method for telling the user what the program is about
def about():
    messagebox.showinfo("About", "My name is Frazia Kipimo:) This is my hashing application! The application can be used to convert text to an assortment of salted hashed values."
                                 " Enjoy!")
# Method for telling the user how to utilize the program
def help():
    messagebox.showinfo("Help", "Enter in a string of text then click submit to retrieve salted hashed values of the string.")

#Creating a Menu Bar
menu_bar = tk.Menu(window)
window.config(menu=menu_bar)
# Gets rid of the button with ---- in the Menu Bar
file_menu = tk.Menu(menu_bar, tearoff=False)

#Creating options to be selected in the Menu Bar
menu_bar.add_cascade(label="Exit", command=exit_app)
menu_bar.add_cascade(label="Help", command=help)
menu_bar.add_cascade(label="About", command=about)

#A loop to continue running the program
window.mainloop()