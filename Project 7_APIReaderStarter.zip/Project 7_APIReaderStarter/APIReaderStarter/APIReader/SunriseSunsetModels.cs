﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace APIReader
{
    // Root myDeserializedClass = JsonSerializer.Deserialize<Root>(myJsonResponse);
    public class Results
    {
        [JsonPropertyName("sunrise")]
        public string sunrise { get; set; }

        [JsonPropertyName("sunset")]
        public string sunset { get; set; }

        [JsonPropertyName("civil_twilight_begin")]
        public string civil_twilight_begin { get; set; }

        [JsonPropertyName("civil_twilight_end")]
        public string civil_twilight_end { get; set; }

        [JsonPropertyName("nautical_twilight_begin")]
        public string nautical_twilight_begin { get; set; }

        [JsonPropertyName("nautical_twilight_end")]
        public string nautical_twilight_end { get; set; }

        [JsonPropertyName("astronomical_twilight_begin")]
        public string astronomical_twilight_begin { get; set; }

        [JsonPropertyName("astronomical_twilight_end")]
        public string astronomical_twilight_end { get; set; }
    }

    public class Root
    {
        [JsonPropertyName("results")]
        public Results results { get; set; }

        [JsonPropertyName("status")]
        public string status { get; set; }

        [JsonPropertyName("tzid")]
        public string tzid { get; set; }
    }
}
