﻿//Frazia Kipimo
//Project 7 - API Reader

//This project uses an API to do a get request and uses it to display information to the window using
//longitude and latitude.

using Newtonsoft.Json;
using System.Collections.Generic;
using System;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace APIReader
{
    // https://sunrise-sunset.org/api
    // https://json2csharp.com/

    public partial class Form1 : Form
    {

        private List<Location> locations = new List<Location>();
        private bool mouseClick = false;

        //Where the program initializes.
        public Form1()
        {
            InitializeComponent();
        }

        //Does a get request for the API URL provided with the specified values that are being requested.
        public async Task GetSunriseSunsetAsync(double lat, double lng)
        {
            // Define the URL of the REST API
            string URL = $"https://api.sunrise-sunset.org/json?lat={lat}&lng={lng}";

            // Create an instance of HttpClient
            using (HttpClient client = new HttpClient())
            {
                try
                {
                    // Make a GET request to the API endpoint
                    HttpResponseMessage response = await client.GetAsync(URL);

                    // Check if the response is successful
                    if (response.IsSuccessStatusCode)
                    {
                        // Read the content as a string
                        string jsonString = await response.Content.ReadAsStringAsync();
                        Root root = JsonConvert.DeserializeObject<Root>(jsonString);

                        //
                        // Populate the user interface here!
                        //
                        if (root.status == "OK")
                        {
                            Results time = root.results;

                            // Display times for each item specified in the labels.
                            lblSunrise.Text = $"{ConvertToLocalTime(time.sunrise)}";
                            lblSunset.Text = $"{ConvertToLocalTime(time.sunset)}";
                            lblCivilTwilightBegin.Text = $"{ConvertToLocalTime(time.civil_twilight_begin)}";
                            lblCivilTwilightEnd.Text = $"{ConvertToLocalTime(time.civil_twilight_end)}";
                            lblNauticalTwilightBegin.Text = $"{ConvertToLocalTime(time.nautical_twilight_begin)}";
                            lblNauticalTwilightEnd.Text = $"{ConvertToLocalTime(time.nautical_twilight_end)}";
                            lblAstronomicalTwilightBegin.Text = $"{ConvertToLocalTime(time.astronomical_twilight_begin)}";
                            lblAstronomicalTwilightEnd.Text = $"{ConvertToLocalTime(time.astronomical_twilight_end)}";

                        }

                        //Parses the UTC Date Time.
                        DateTime ParseUtcDateTime(string utcTimeString)
                        {
                            // Parse the UTC time string
                            var utcDateTime = DateTime.Parse(utcTimeString, null, System.Globalization.DateTimeStyles.AdjustToUniversal);
                            if (utcDateTime.Kind != DateTimeKind.Utc)
                            {
                                utcDateTime = DateTime.SpecifyKind(utcDateTime, DateTimeKind.Utc);
                            }
                            return utcDateTime;
                        }

                        //Converts the Date Time to EST which is my local time zone using the Parsed UTC Date Time Method.
                        string ConvertToLocalTime(string utcTime)
                        {
                            try
                            {
                                // Parse the UTC time string and convert it to a DateTime object
                                DateTime utcDateTime = ParseUtcDateTime(utcTime);

                                // Convert the UTC time to local time
                                TimeZoneInfo localTimeZone = TimeZoneInfo.Local;
                                DateTime localDateTime = TimeZoneInfo.ConvertTimeFromUtc(utcDateTime, localTimeZone);
                                return localDateTime.ToShortTimeString();
                            }
                            //Displays an error message when an invalid time is displayed or attempted to be converted.
                            catch (Exception ex)
                            {
                                MessageBox.Show($"Error converting time: {ex.Message}");
                                return "Invalid Time";
                            }
                        }

                        txtLat.Text = "";
                        txtLat.Focus();

                        txtLng.Text = "";
                        txtLng.Focus();

                        if (!mouseClick)
                        {
                            var listItem = new ListViewItem(lat.ToString());
                            var listItem1 = new ListViewItem(lng.ToString());
                            if (lstLocations.Items.Count > 0)
                            {
                                ListViewItem item = new ListViewItem();
                                lstLocations.Items.Add(item);
                                mouseClick = false;
                            }

                        }

                    }
                    else
                    {
                        MessageBox.Show($"Coordinates Error: {response.StatusCode}");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Exception: {ex.Message}");
                }
            }

        }

        //Shows what text will be on the design form for the labels listed below.
        public void clearForm()
        {
            lblLat.Text = "Lat: ";
            lblLng.Text = "Lng: ";
            lblSunrise.Text = "";
            lblSunset.Text = "";
            lblCivilTwilightBegin.Text = "";
            lblCivilTwilightEnd.Text = "";
            label14.Text = "Nautical Twilight Begin: ";
            lblNauticalTwilightEnd.Text = "";
            label4.Text = "Astronomical Twilight Begin: ";
            lblAstronomicalTwilightBegin.Text = "";
            lblNauticalTwilightBegin.Text = "";
            lblAstronomicalTwilightEnd.Text = "";
        }

        //Displays a list view labelled "Coordinates:" that will display on load.
        private void Form1_Load(object sender, EventArgs e)
        {
            lstLocations.Columns.Add("Coordinates:", 120);
            lstLocations.FullRowSelect = true;
            clearForm();
        }

        //When btnExit is clicked, it will exit out of the application.
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //Exits out of the Tool Strip Menu Item when clicked.
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //When clicked, the program will retrieve the information about the location based on the coordinates
        //and display them to the screen next to their designated labels.
        private void btnEnter_Click(object sender, EventArgs e)
        {
            // Parse the latitude and longitude values
            double lat, lng;
            if (double.TryParse(txtLat.Text, out lat) && double.TryParse(txtLng.Text, out lng))
            {
                // Combine latitude and longitude into a single formatted string
                string coordinates = $"{lat}, {lng}";

                // Add the new location to the ListView
                var listItem = new ListViewItem(coordinates);
                lstLocations.Items.Add(listItem);

                // Fetch and display the sunrise and sunset times
                _ = GetSunriseSunsetAsync(lat, lng);
            }
            //Displays an error message to the screen when an invalid value is entered.
            else
            {
                MessageBox.Show("Please enter valid latitude and longitude values.");
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txtZipcode_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblSunset_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void lblPressure_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
