﻿namespace APIReader
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnEnter = new System.Windows.Forms.Button();
            this.txtLat = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.lblCivilTwilightEnd = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblAstronomicalTwilightEnd = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lblNauticalTwilightBegin = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblWind = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblSunset = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblSunrise = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblAstronomicalTwilightBegin = new System.Windows.Forms.Label();
            this.lblCivilTwilightBegin = new System.Windows.Forms.Label();
            this.lblDesc = new System.Windows.Forms.Label();
            this.lblNauticalTwilightEnd = new System.Windows.Forms.Label();
            this.lblLat = new System.Windows.Forms.Label();
            this.lstLocations = new System.Windows.Forms.ListView();
            this.btnExit = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lblLng = new System.Windows.Forms.Label();
            this.txtLng = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnEnter
            // 
            this.btnEnter.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnEnter.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.btnEnter.Location = new System.Drawing.Point(311, 41);
            this.btnEnter.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(144, 83);
            this.btnEnter.TabIndex = 1;
            this.btnEnter.Text = "Enter";
            this.btnEnter.UseVisualStyleBackColor = false;
            this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
            // 
            // txtLat
            // 
            this.txtLat.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLat.Location = new System.Drawing.Point(97, 43);
            this.txtLat.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtLat.Name = "txtLat";
            this.txtLat.Size = new System.Drawing.Size(186, 39);
            this.txtLat.TabIndex = 0;
            this.txtLat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtLat.TextChanged += new System.EventHandler(this.txtZipcode_TextChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Highlight;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lblCivilTwilightEnd);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.lblAstronomicalTwilightEnd);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.lblNauticalTwilightBegin);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.lblWind);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.lblSunset);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.lblSunrise);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.lblAstronomicalTwilightBegin);
            this.panel1.Controls.Add(this.lblCivilTwilightBegin);
            this.panel1.Controls.Add(this.lblDesc);
            this.panel1.Controls.Add(this.lblNauticalTwilightEnd);
            this.panel1.Location = new System.Drawing.Point(663, 29);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(486, 323);
            this.panel1.TabIndex = 2;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label1
            // 
            this.label1.ForeColor = System.Drawing.SystemColors.Window;
            this.label1.Location = new System.Drawing.Point(113, 133);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 39);
            this.label1.TabIndex = 26;
            this.label1.Text = "Civil Twilight End:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblCivilTwilightEnd
            // 
            this.lblCivilTwilightEnd.ForeColor = System.Drawing.SystemColors.Window;
            this.lblCivilTwilightEnd.Location = new System.Drawing.Point(251, 133);
            this.lblCivilTwilightEnd.Name = "lblCivilTwilightEnd";
            this.lblCivilTwilightEnd.Size = new System.Drawing.Size(143, 39);
            this.lblCivilTwilightEnd.TabIndex = 23;
            this.lblCivilTwilightEnd.Text = "Civil Twilight End";
            this.lblCivilTwilightEnd.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.ForeColor = System.Drawing.SystemColors.Window;
            this.label12.Location = new System.Drawing.Point(48, 279);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(197, 39);
            this.label12.TabIndex = 21;
            this.label12.Text = "Astronomical Twilight End:";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblAstronomicalTwilightEnd
            // 
            this.lblAstronomicalTwilightEnd.ForeColor = System.Drawing.SystemColors.Window;
            this.lblAstronomicalTwilightEnd.Location = new System.Drawing.Point(251, 279);
            this.lblAstronomicalTwilightEnd.Name = "lblAstronomicalTwilightEnd";
            this.lblAstronomicalTwilightEnd.Size = new System.Drawing.Size(199, 39);
            this.lblAstronomicalTwilightEnd.TabIndex = 20;
            this.lblAstronomicalTwilightEnd.Text = "Astronomical Twilight End";
            this.lblAstronomicalTwilightEnd.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.ForeColor = System.Drawing.SystemColors.Window;
            this.label14.Location = new System.Drawing.Point(74, 172);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(171, 39);
            this.label14.TabIndex = 19;
            this.label14.Text = "Nautical Twilight Begin:";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // lblNauticalTwilightBegin
            // 
            this.lblNauticalTwilightBegin.ForeColor = System.Drawing.SystemColors.Window;
            this.lblNauticalTwilightBegin.Location = new System.Drawing.Point(251, 172);
            this.lblNauticalTwilightBegin.Name = "lblNauticalTwilightBegin";
            this.lblNauticalTwilightBegin.Size = new System.Drawing.Size(179, 39);
            this.lblNauticalTwilightBegin.TabIndex = 18;
            this.lblNauticalTwilightBegin.Text = "Nautical Twilight Begin";
            this.lblNauticalTwilightBegin.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblNauticalTwilightBegin.Click += new System.EventHandler(this.lblPressure_Click);
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(0, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 23);
            this.label10.TabIndex = 24;
            // 
            // lblWind
            // 
            this.lblWind.Location = new System.Drawing.Point(0, 0);
            this.lblWind.Name = "lblWind";
            this.lblWind.Size = new System.Drawing.Size(100, 23);
            this.lblWind.TabIndex = 27;
            // 
            // label8
            // 
            this.label8.ForeColor = System.Drawing.SystemColors.Window;
            this.label8.Location = new System.Drawing.Point(181, 56);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 39);
            this.label8.TabIndex = 15;
            this.label8.Text = "Sunset:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblSunset
            // 
            this.lblSunset.ForeColor = System.Drawing.SystemColors.Window;
            this.lblSunset.Location = new System.Drawing.Point(251, 56);
            this.lblSunset.Name = "lblSunset";
            this.lblSunset.Size = new System.Drawing.Size(116, 39);
            this.lblSunset.TabIndex = 14;
            this.lblSunset.Text = "Sunset";
            this.lblSunset.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblSunset.Click += new System.EventHandler(this.lblSunset_Click);
            // 
            // label6
            // 
            this.label6.ForeColor = System.Drawing.SystemColors.Window;
            this.label6.Location = new System.Drawing.Point(176, 17);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 39);
            this.label6.TabIndex = 13;
            this.label6.Text = "Sunrise:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblSunrise
            // 
            this.lblSunrise.ForeColor = System.Drawing.SystemColors.Window;
            this.lblSunrise.Location = new System.Drawing.Point(251, 17);
            this.lblSunrise.Name = "lblSunrise";
            this.lblSunrise.Size = new System.Drawing.Size(116, 39);
            this.lblSunrise.TabIndex = 12;
            this.lblSunrise.Text = "Sunrise";
            this.lblSunrise.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.ForeColor = System.Drawing.SystemColors.Window;
            this.label5.Location = new System.Drawing.Point(98, 94);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(147, 39);
            this.label5.TabIndex = 11;
            this.label5.Text = "Civil Twilight Begin:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.ForeColor = System.Drawing.SystemColors.Window;
            this.label4.Location = new System.Drawing.Point(36, 248);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(209, 31);
            this.label4.TabIndex = 10;
            this.label4.Text = "Astronomical Twilight Begin:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.ForeColor = System.Drawing.SystemColors.Window;
            this.label3.Location = new System.Drawing.Point(78, 211);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(167, 31);
            this.label3.TabIndex = 9;
            this.label3.Text = "Nautical Twilight End:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // lblAstronomicalTwilightBegin
            // 
            this.lblAstronomicalTwilightBegin.ForeColor = System.Drawing.SystemColors.Window;
            this.lblAstronomicalTwilightBegin.Location = new System.Drawing.Point(236, 248);
            this.lblAstronomicalTwilightBegin.Name = "lblAstronomicalTwilightBegin";
            this.lblAstronomicalTwilightBegin.Size = new System.Drawing.Size(103, 31);
            this.lblAstronomicalTwilightBegin.TabIndex = 8;
            this.lblAstronomicalTwilightBegin.Text = "Astronomical Twilight Begin";
            this.lblAstronomicalTwilightBegin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCivilTwilightBegin
            // 
            this.lblCivilTwilightBegin.ForeColor = System.Drawing.SystemColors.Window;
            this.lblCivilTwilightBegin.Location = new System.Drawing.Point(251, 94);
            this.lblCivilTwilightBegin.Name = "lblCivilTwilightBegin";
            this.lblCivilTwilightBegin.Size = new System.Drawing.Size(143, 39);
            this.lblCivilTwilightBegin.TabIndex = 6;
            this.lblCivilTwilightBegin.Text = "Civil Twilight Begin";
            this.lblCivilTwilightBegin.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblDesc
            // 
            this.lblDesc.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDesc.ForeColor = System.Drawing.SystemColors.Window;
            this.lblDesc.Location = new System.Drawing.Point(268, 59);
            this.lblDesc.Name = "lblDesc";
            this.lblDesc.Size = new System.Drawing.Size(115, 47);
            this.lblDesc.TabIndex = 4;
            this.lblDesc.Text = "Description";
            this.lblDesc.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNauticalTwilightEnd
            // 
            this.lblNauticalTwilightEnd.ForeColor = System.Drawing.SystemColors.Window;
            this.lblNauticalTwilightEnd.Location = new System.Drawing.Point(251, 211);
            this.lblNauticalTwilightEnd.Name = "lblNauticalTwilightEnd";
            this.lblNauticalTwilightEnd.Size = new System.Drawing.Size(161, 31);
            this.lblNauticalTwilightEnd.TabIndex = 3;
            this.lblNauticalTwilightEnd.Text = "Nautical Twilight End";
            this.lblNauticalTwilightEnd.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblLat
            // 
            this.lblLat.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLat.Location = new System.Drawing.Point(13, 41);
            this.lblLat.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLat.Name = "lblLat";
            this.lblLat.Size = new System.Drawing.Size(76, 39);
            this.lblLat.TabIndex = 3;
            this.lblLat.Text = "Lat:";
            this.lblLat.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lstLocations
            // 
            this.lstLocations.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.lstLocations.HideSelection = false;
            this.lstLocations.Location = new System.Drawing.Point(12, 135);
            this.lstLocations.Name = "lstLocations";
            this.lstLocations.Size = new System.Drawing.Size(271, 199);
            this.lstLocations.TabIndex = 4;
            this.lstLocations.UseCompatibleStateImageBehavior = false;
            this.lstLocations.View = System.Windows.Forms.View.Details;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.Control;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(477, 41);
            this.btnExit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(134, 83);
            this.btnExit.TabIndex = 2;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1190, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.toolStripSeparator1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            //
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(100, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // lblLng
            // 
            this.lblLng.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLng.Location = new System.Drawing.Point(13, 88);
            this.lblLng.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLng.Name = "lblLng";
            this.lblLng.Size = new System.Drawing.Size(76, 39);
            this.lblLng.TabIndex = 5;
            this.lblLng.Text = "Lng:";
            this.lblLng.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtLng
            // 
            this.txtLng.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLng.Location = new System.Drawing.Point(97, 88);
            this.txtLng.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtLng.Name = "txtLng";
            this.txtLng.Size = new System.Drawing.Size(186, 39);
            this.txtLng.TabIndex = 6;
            this.txtLng.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form1
            // 
            this.AcceptButton = this.btnEnter;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::APIReader.Properties.Resources.clouds_2329680_640;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(1190, 356);
            this.Controls.Add(this.txtLng);
            this.Controls.Add(this.lblLng);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lstLocations);
            this.Controls.Add(this.lblLat);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtLat);
            this.Controls.Add(this.btnEnter);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sunrise and Sunset";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.TextBox txtLat;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblLat;
        private System.Windows.Forms.Label lblNauticalTwilightEnd;
        private System.Windows.Forms.Label lblDesc;
        private System.Windows.Forms.Label lblCivilTwilightBegin;
        private System.Windows.Forms.ListView lstLocations;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblSunset;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblSunrise;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblWind;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblAstronomicalTwilightEnd;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblNauticalTwilightBegin;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblAstronomicalTwilightBegin;
        private System.Windows.Forms.Label lblLng;
        private System.Windows.Forms.TextBox txtLng;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblCivilTwilightEnd;
    }
}
