﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace APIReader
{
    // https://openweathermap.org/current
    // https://json2csharp.com/

    public partial class Form1 : Form
    {

        private List<Location> locations = new List<Location>();
        private bool mouseClick = false;

        public Form1()
        {
            InitializeComponent();
        }

        public async Task GetWeatherAsync(string zipcode)
        {
            // Define the URL of the REST API
            string URL = @"https://api.openweathermap.org/data/2.5/weather?zip=" + zipcode + @",us&units=imperial&appid=b63e8b25d9ec31d07dd9784b3d9f133e";

            // Create an instance of HttpClient
            using (HttpClient client = new HttpClient())
            {
                try
                {
                    // Make a GET request to the API endpoint
                    HttpResponseMessage response = await client.GetAsync(URL);

                    // Check if the response is successful
                    if (response.IsSuccessStatusCode)
                    {
                        // Read the content as a string
                        string jsonString = await response.Content.ReadAsStringAsync();
                        Root root = JsonConvert.DeserializeObject<Root>(jsonString);

                        //
                        // Populate the user interface here!
                        //
                        lblLat.Text = "Lat: " + root.coord.lat.ToString();
                        lblLon.Text = "Lon: " + root.coord.lon.ToString();
                        lblName.Text = root.name;
                        lblDesc.Text = root.weather[0].description;
                        lblTemp.Text = root.main.temp.ToString() + "F";
                        lblSunrise.Text = UnixEpochToEST(root.sys.sunrise);
                        lblSunset.Text = UnixEpochToEST(root.sys.sunset);
                        lblWind.Text = root.wind.speed.ToString() + "mph";
                   
                        txtZipcode.Text = "";
                        txtZipcode.Focus();

                        if (!mouseClick)
                        {
                            var found = locations.Find(x => x.ZipCode == zipcode);
                            if(found == null)
                            {
                                locations.Add(new Location() { ZipCode = zipcode });
                                ListViewItem item = new ListViewItem(zipcode);
                                lstLocations.Items.Add(item);
                                mouseClick = false;
                            }
                            
                        }

                    }
                    else
                    {
                        MessageBox.Show($"Zipcode Error: {response.StatusCode}");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Exception: {ex.Message}");
                }
            }
        }

        public void clearForm()
        {
            lblLat.Text = "Lat: ";
            lblLon.Text = "Lon: ";
            lblName.Text = "";
            lblDesc.Text = "";
            lblTemp.Text = "0 F";

            lblSunrise.Text = "";
            lblSunset.Text = "";

            lblWind.Text = "0 mph";
            lblPressure.Text = "0 hPa";
            lblHumidity.Text = "0 %";
        }

        private string UnixEpochToEST(long unixTimestamp)
        {
            // Convert to DateTime (UTC)
            DateTime utcDateTime = DateTimeOffset.FromUnixTimeSeconds(unixTimestamp).UtcDateTime;

            // Convert to Eastern Standard Time (EST)
            TimeZoneInfo estTimeZone = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
            DateTime estDateTime = TimeZoneInfo.ConvertTimeFromUtc(utcDateTime, estTimeZone);

            //For Testing and Verifying Time
            //Console.WriteLine($"Unix timestamp: {unixTimestamp}");
            //Console.WriteLine($"UTC DateTime: {utcDateTime}");
            //Console.WriteLine($"EST DateTime: {estDateTime}");

            return estDateTime.ToShortTimeString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lstLocations.Columns.Add("Zipcode", 120);
            lstLocations.FullRowSelect = true;
            clearForm();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void lstLocations_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            int index = lstLocations.SelectedIndices[0];
            string zipcode = locations[index].ZipCode;
            mouseClick = true;
            _ = GetWeatherAsync(zipcode);
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (StreamWriter outputFile = new StreamWriter(Path.Combine("./", "zipcodes.txt")))
            {
                foreach (Location loc in locations)
                    outputFile.WriteLine(loc.ZipCode);
                clearForm();
                lstLocations.Items.Clear();
                locations.Clear();
            }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string filePath = "./zipcodes.txt";

            try
            {
                using (StreamReader reader = new StreamReader(filePath))
                {
                    locations.Clear();
                    lstLocations.Items.Clear();
                    clearForm();
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        locations.Add(new Location() { ZipCode = line });
                    }

                    foreach (Location loc in locations)
                    {
                        ListViewItem item = new ListViewItem(loc.ZipCode);
                        lstLocations.Items.Add(item);
                    }

                }
            }
            catch (FileNotFoundException)
            {
                MessageBox.Show("File not found. Please check the file path.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

        private void btnAddZipcode_Click(object sender, EventArgs e)
        {
            if (txtZipcode.Text != "")
            {
                mouseClick = false;
                _ = GetWeatherAsync(txtZipcode.Text);
            }
            else
            {
                txtZipcode.Text = string.Empty;
                txtZipcode.Focus();
            }
        }
    }
}
