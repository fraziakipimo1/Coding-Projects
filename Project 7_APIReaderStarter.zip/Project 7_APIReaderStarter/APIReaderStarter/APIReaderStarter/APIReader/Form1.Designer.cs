﻿namespace APIReader
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnAddZipcode = new System.Windows.Forms.Button();
            this.txtZipcode = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.lblHumidity = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lblPressure = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblWind = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblSunset = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblSunrise = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pboxIcon = new System.Windows.Forms.PictureBox();
            this.lblTemp = new System.Windows.Forms.Label();
            this.pbxWeatherIcon = new System.Windows.Forms.PictureBox();
            this.lblDesc = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblLon = new System.Windows.Forms.Label();
            this.lblLat = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lstLocations = new System.Windows.Forms.ListView();
            this.btnExit = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pboxIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxWeatherIcon)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnAddZipcode
            // 
            this.btnAddZipcode.BackColor = System.Drawing.Color.Orange;
            this.btnAddZipcode.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddZipcode.Location = new System.Drawing.Point(509, 24);
            this.btnAddZipcode.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnAddZipcode.Name = "btnAddZipcode";
            this.btnAddZipcode.Size = new System.Drawing.Size(178, 48);
            this.btnAddZipcode.TabIndex = 1;
            this.btnAddZipcode.Text = "Add Zipcode";
            this.btnAddZipcode.UseVisualStyleBackColor = false;
            this.btnAddZipcode.Click += new System.EventHandler(this.btnAddZipcode_Click);
            // 
            // txtZipcode
            // 
            this.txtZipcode.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtZipcode.Location = new System.Drawing.Point(176, 33);
            this.txtZipcode.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtZipcode.Name = "txtZipcode";
            this.txtZipcode.Size = new System.Drawing.Size(321, 39);
            this.txtZipcode.TabIndex = 0;
            this.txtZipcode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Highlight;
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.lblHumidity);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.lblPressure);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.lblWind);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.lblSunset);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.lblSunrise);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.pboxIcon);
            this.panel1.Controls.Add(this.lblTemp);
            this.panel1.Controls.Add(this.pbxWeatherIcon);
            this.panel1.Controls.Add(this.lblDesc);
            this.panel1.Controls.Add(this.lblName);
            this.panel1.Controls.Add(this.lblLon);
            this.panel1.Controls.Add(this.lblLat);
            this.panel1.Location = new System.Drawing.Point(32, 80);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(522, 349);
            this.panel1.TabIndex = 2;
            // 
            // label12
            // 
            this.label12.ForeColor = System.Drawing.SystemColors.Window;
            this.label12.Location = new System.Drawing.Point(192, 290);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(78, 39);
            this.label12.TabIndex = 21;
            this.label12.Text = "Humidity:";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblHumidity
            // 
            this.lblHumidity.ForeColor = System.Drawing.SystemColors.Window;
            this.lblHumidity.Location = new System.Drawing.Point(268, 291);
            this.lblHumidity.Name = "lblHumidity";
            this.lblHumidity.Size = new System.Drawing.Size(116, 39);
            this.lblHumidity.TabIndex = 20;
            this.lblHumidity.Text = "Humidity";
            this.lblHumidity.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.ForeColor = System.Drawing.SystemColors.Window;
            this.label14.Location = new System.Drawing.Point(197, 252);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(73, 39);
            this.label14.TabIndex = 19;
            this.label14.Text = "Pressure:";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblPressure
            // 
            this.lblPressure.ForeColor = System.Drawing.SystemColors.Window;
            this.lblPressure.Location = new System.Drawing.Point(268, 251);
            this.lblPressure.Name = "lblPressure";
            this.lblPressure.Size = new System.Drawing.Size(116, 39);
            this.lblPressure.TabIndex = 18;
            this.lblPressure.Text = "Pressure";
            this.lblPressure.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label10
            // 
            this.label10.ForeColor = System.Drawing.SystemColors.Window;
            this.label10.Location = new System.Drawing.Point(214, 211);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 39);
            this.label10.TabIndex = 17;
            this.label10.Text = "Wind:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblWind
            // 
            this.lblWind.ForeColor = System.Drawing.SystemColors.Window;
            this.lblWind.Location = new System.Drawing.Point(268, 212);
            this.lblWind.Name = "lblWind";
            this.lblWind.Size = new System.Drawing.Size(116, 39);
            this.lblWind.TabIndex = 16;
            this.lblWind.Text = "Wind";
            this.lblWind.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            this.label8.ForeColor = System.Drawing.SystemColors.Window;
            this.label8.Location = new System.Drawing.Point(206, 173);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 39);
            this.label8.TabIndex = 15;
            this.label8.Text = "Sunset:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblSunset
            // 
            this.lblSunset.ForeColor = System.Drawing.SystemColors.Window;
            this.lblSunset.Location = new System.Drawing.Point(268, 172);
            this.lblSunset.Name = "lblSunset";
            this.lblSunset.Size = new System.Drawing.Size(116, 39);
            this.lblSunset.TabIndex = 14;
            this.lblSunset.Text = "Sunset";
            this.lblSunset.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.ForeColor = System.Drawing.SystemColors.Window;
            this.label6.Location = new System.Drawing.Point(201, 134);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 39);
            this.label6.TabIndex = 13;
            this.label6.Text = "Sunrise:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblSunrise
            // 
            this.lblSunrise.ForeColor = System.Drawing.SystemColors.Window;
            this.lblSunrise.Location = new System.Drawing.Point(268, 133);
            this.lblSunrise.Name = "lblSunrise";
            this.lblSunrise.Size = new System.Drawing.Size(116, 39);
            this.lblSunrise.TabIndex = 12;
            this.lblSunrise.Text = "Sunrise";
            this.lblSunrise.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.ForeColor = System.Drawing.SystemColors.Window;
            this.label5.Location = new System.Drawing.Point(168, 94);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 39);
            this.label5.TabIndex = 11;
            this.label5.Text = "Temperature:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.ForeColor = System.Drawing.SystemColors.Window;
            this.label4.Location = new System.Drawing.Point(172, 58);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 31);
            this.label4.TabIndex = 10;
            this.label4.Text = "Description:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.ForeColor = System.Drawing.SystemColors.Window;
            this.label3.Location = new System.Drawing.Point(193, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 31);
            this.label3.TabIndex = 9;
            this.label3.Text = "Location:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.ForeColor = System.Drawing.SystemColors.Window;
            this.label2.Location = new System.Drawing.Point(13, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 31);
            this.label2.TabIndex = 8;
            this.label2.Text = "Coordinates:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pboxIcon
            // 
            this.pboxIcon.BackColor = System.Drawing.Color.Silver;
            this.pboxIcon.Location = new System.Drawing.Point(446, 3);
            this.pboxIcon.Name = "pboxIcon";
            this.pboxIcon.Size = new System.Drawing.Size(73, 64);
            this.pboxIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pboxIcon.TabIndex = 7;
            this.pboxIcon.TabStop = false;
            // 
            // lblTemp
            // 
            this.lblTemp.ForeColor = System.Drawing.SystemColors.Window;
            this.lblTemp.Location = new System.Drawing.Point(268, 94);
            this.lblTemp.Name = "lblTemp";
            this.lblTemp.Size = new System.Drawing.Size(116, 39);
            this.lblTemp.TabIndex = 6;
            this.lblTemp.Text = "Temperature";
            this.lblTemp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pbxWeatherIcon
            // 
            this.pbxWeatherIcon.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pbxWeatherIcon.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbxWeatherIcon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxWeatherIcon.Location = new System.Drawing.Point(50, 134);
            this.pbxWeatherIcon.Name = "pbxWeatherIcon";
            this.pbxWeatherIcon.Size = new System.Drawing.Size(0, 113);
            this.pbxWeatherIcon.TabIndex = 5;
            this.pbxWeatherIcon.TabStop = false;
            // 
            // lblDesc
            // 
            this.lblDesc.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDesc.ForeColor = System.Drawing.SystemColors.Window;
            this.lblDesc.Location = new System.Drawing.Point(268, 59);
            this.lblDesc.Name = "lblDesc";
            this.lblDesc.Size = new System.Drawing.Size(108, 31);
            this.lblDesc.TabIndex = 4;
            this.lblDesc.Text = "Description";
            this.lblDesc.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblName
            // 
            this.lblName.ForeColor = System.Drawing.SystemColors.Window;
            this.lblName.Location = new System.Drawing.Point(268, 17);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(152, 31);
            this.lblName.TabIndex = 3;
            this.lblName.Text = "Location";
            this.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblLon
            // 
            this.lblLon.ForeColor = System.Drawing.SystemColors.Window;
            this.lblLon.Location = new System.Drawing.Point(25, 77);
            this.lblLon.Name = "lblLon";
            this.lblLon.Size = new System.Drawing.Size(108, 31);
            this.lblLon.TabIndex = 2;
            this.lblLon.Text = "Coord";
            this.lblLon.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLat
            // 
            this.lblLat.ForeColor = System.Drawing.SystemColors.Window;
            this.lblLat.Location = new System.Drawing.Point(25, 48);
            this.lblLat.Name = "lblLat";
            this.lblLat.Size = new System.Drawing.Size(108, 29);
            this.lblLat.TabIndex = 1;
            this.lblLat.Text = "Coord";
            this.lblLat.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(55, 33);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 39);
            this.label1.TabIndex = 3;
            this.label1.Text = "Zipcode:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lstLocations
            // 
            this.lstLocations.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.lstLocations.HideSelection = false;
            this.lstLocations.Location = new System.Drawing.Point(561, 80);
            this.lstLocations.Name = "lstLocations";
            this.lstLocations.Size = new System.Drawing.Size(126, 349);
            this.lstLocations.TabIndex = 4;
            this.lstLocations.UseCompatibleStateImageBehavior = false;
            this.lstLocations.View = System.Windows.Forms.View.Details;
            this.lstLocations.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lstLocations_MouseDoubleClick);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Gray;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(509, 439);
            this.btnExit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(178, 48);
            this.btnExit.TabIndex = 2;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(719, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.toolStripSeparator1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.openToolStripMenuItem.Text = "Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(100, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.btnAddZipcode;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::APIReader.Properties.Resources.clouds_2329680_640;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(719, 492);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lstLocations);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtZipcode);
            this.Controls.Add(this.btnAddZipcode);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Weather Lookup";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pboxIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxWeatherIcon)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAddZipcode;
        private System.Windows.Forms.TextBox txtZipcode;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblLon;
        private System.Windows.Forms.Label lblLat;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblDesc;
        private System.Windows.Forms.PictureBox pbxWeatherIcon;
        private System.Windows.Forms.Label lblTemp;
        private System.Windows.Forms.ListView lstLocations;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.PictureBox pboxIcon;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblSunset;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblSunrise;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblWind;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblHumidity;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblPressure;
    }
}

